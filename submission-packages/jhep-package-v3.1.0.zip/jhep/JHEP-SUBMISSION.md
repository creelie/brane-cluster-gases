# JHEP submission package — what to upload and what to enter

Files in this folder:

- `uv-finite-brane-gas-jhep-source-v3.1.0.zip` — the source in the JHEP class: `uv-finite-brane-gas-jhep.tex`, `jheppub.sty` (the journal's style file, LPPL) and the fifteen figure panels in `figs/`. Three `pdflatex` passes give 83 pages, no bad box, no undefined reference. The bibliography is inside the `.tex` (no `.bib`). The content is identical to the PRD version; only the class, the front matter (JHEP `\author`/`\affiliation`/`\emailAdd`/`\abstract`/`\keywords`), single-column floats, table rules and the JHEP keyword list differ.
- `uv-finite-brane-gas-jhep-v3.1.0.pdf` — the compiled paper (JHEP layout, with table of contents).
- `supplemental-material-v3.1.0.zip` — the verification and audit code, for the "supplementary material" upload if the editor wants it (JHEP does not require it; the paper's Data availability section points to the Zenodo archive).

## Submission (https://jhep.sissa.it, "Submit a paper")

**Journal:** JHEP. **Article type:** regular article (hep-th).

**Title**

Cancellation of all ultraviolet divergences of quantum gravity by a scale-invariant gas of branes

**Authors**

1. Deep Bhattacharjee — ORCID 0000-0003-0466-750X — itsdeep@live.com (second address d.bhattacharjee@erl-forschung.de) — Formerly, Electro-Gravitational Space Propulsion Laboratory (EGSPL), Bhubaneswar, Odisha 751030, India; Formerly, University of Calcutta, Senate House, 87/1 College Street, Kolkata 700073, West Bengal, India. **Corresponding author.**
2. Ushashi Bhattacharya — ORCID 0009-0002-2254-3914 — rai.bhattacharya.in@gmail.com — Formerly, National Taiwan University, Taipei 106319, Taiwan.

**Abstract** — the same text as in the paper (see `PRD-SUBMISSION.md` in the PRD package or the first page of the PDF).

**Keywords** (from the JHEP list; these three are set in the paper): Models of Quantum Gravity; Renormalization and Regularization; Scattering Amplitudes.

**arXiv number:** JHEP asks for one and strongly prefers that the paper be on arXiv. If the paper is posted on arXiv before submission, enter the number and also put it in the source as `\arxivnumber{...}` before `\maketitle`. If it is only on Hexagon, say so in the cover letter and leave the field empty; this is allowed.

**Open access:** JHEP is fully open access under SCOAP3; there is no charge to the authors and nothing to select.

**Previous submission:** the manuscript was previously submitted to Physical Review D under the title "Finite quantum gravity from a scale-invariant gas of branes" and rejected; JHEP's form asks whether the paper was submitted elsewhere, answer yes and name PRD. It is not under consideration elsewhere now.

**Suggested referees:** optional; leave to the authors.

**Funding / competing interests:** none (stated in the paper).

**Use of AI:** JHEP has no separate field; the paper's "Use of AI tools" section is the disclosure.

## Cover letter

Dear Editor,

We submit the manuscript "Cancellation of all ultraviolet divergences of quantum gravity by a scale-invariant gas of branes" by Deep Bhattacharjee and Ushashi Bhattacharya for publication in JHEP.

The paper proves one theorem. A frozen Poisson gas of branes with no preferred size multiplies the graviton kinetic operator by an entire function without zeros, exp[(n/2) Ein(Box^2/M^4)] times a random factor with a limit at high momentum, and for n >= 4 the theory of gravity built on that operator has no ultraviolet divergence at any order of perturbation theory: every graph with two or more loops converges, the one-loop poles are those of a local theory and are cancelled by three quartic operators with finite coefficients computed in closed form, Newton's constant and the cosmological constant do not run, the zero-point energy is finite and regulator independent, and the physical S matrix is unitary at every loop order. A one-loop graph in closed form confirms the cutting rule and shows that the loop expansion is small only below an energy between 1.4M and 1.9M. The paper states what it does not prove: the free Euclidean field is not reflection positive, and no construction beyond perturbation theory is claimed.

Relative to the nonlocal-gravity literature, in which finiteness for entire form factors of polynomial growth is known (Tomboulis, Modesto, Modesto–Rachwał), the new elements are that the form factor is derived from a physical medium rather than chosen, that the theory is defined by one realization of the gas with its random part controlled in closed form, that the class of admissible single-brane responses is characterized and shown to be exactly the class without zeros, that the fine-graining condition on the gas is forced by a regulator-independent vacuum energy, and that the one-loop tuning, the vacuum energy, the closed-form bubble and its breakdown energy, the regularity and the failure of reflection positivity of the free Euclidean field, and the Newtonian well are computed for this class. The introduction states these points and the discussion sets the construction beside the alternatives in a table.

Every result is derived in the text. The verification code and the independent audit scripts that re-evaluate the formulas are public at https://doi.org/10.5281/zenodo.23524276 (version 3.1.0 of the archive) and are cited in the Data availability section. The manuscript was previously submitted to Physical Review D under an earlier title and was not accepted there; it has been revised throughout since. It is not under consideration elsewhere. The use of AI tools is disclosed in the manuscript; the authors directed the work, checked every result and are responsible for the content. The authors have no competing interests and received no funding.

Yours sincerely,

Deep Bhattacharjee (corresponding author, itsdeep@live.com)
Ushashi Bhattacharya (rai.bhattacharya.in@gmail.com)

# Hexagon submission package — what to enter on the website

Files in this folder:

- `uv-finite-brane-gas-tex-v3.1.0.zip` — the TeX source (`uv-finite-brane-gas.tex` and `figs/`, 17 PNG panels). It compiles on its own with `pdflatex` run three times (REVTeX 4.2, TikZ, cm-super from TeX Live); 50 pages, no bad box, no undefined reference. Hexagon does not accept code in a submission, so the verification suite and the audit scripts are not in the zip; they are linked from the Data availability section of the paper.
- `uv-finite-brane-gas-v3.1.0.pdf` — the compiled paper.

## Title

Cancellation of all ultraviolet divergences of quantum gravity by a scale-invariant gas of branes

## Contributors (in order)

1. Deep Bhattacharjee — ORCID 0000-0003-0466-750X — itsdeep@live.com — Formerly, Electro-Gravitational Space Propulsion Laboratory (EGSPL), Bhubaneswar, Odisha 751030, India; Formerly, University of Calcutta, Senate House, 87/1 College Street, Kolkata 700073, West Bengal, India. Corresponding contributor.
2. Ushashi Bhattacharya — ORCID 0009-0002-2254-3914 — rai.bhattacharya.in@gmail.com — Formerly, National Taiwan University, Taipei 106319, Taiwan.

## Abstract (plain text, 231 words)

A frozen Poisson gas of branes with no preferred size, each brane a layer of independent cells that shift the proper time of a crossing graviton, multiplies the graviton kinetic operator by an entire function without zeros, exp[(n/2) Ein(Box^2/M^4)] times a random factor that tends to a constant at high momentum, in almost every realization. We prove that for n >= 4 the theory of gravity built on it has no ultraviolet divergence at any order of perturbation theory: every graph with two or more loops converges, the one-loop poles are those of a local theory and are cancelled by three operators quartic in curvature with finite coefficients, Newton's constant and the cosmological constant do not run, the zero-point energy of the graviton is 3 n M^4/(64 pi^2) for every regulator, and the physical S matrix is unitary at every loop order. The propagator keeps the graviton pole alone, and the potential of a point mass is finite at the origin. A one-loop graph in closed form confirms the cutting rule and grows faster than any exponential of the energy, so the loop expansion is an expansion in a small parameter only below an energy between 1.4M and 1.9M. The free Euclidean field is a Gaussian measure with finite curvature that is not reflection positive, which states what a construction beyond perturbation theory would have to supply.

## Abstract (LaTeX, if the form accepts it)

A frozen Poisson gas of branes with no preferred size, each brane a layer of independent cells that shift the proper time of a crossing graviton, multiplies the graviton kinetic operator by an entire function without zeros, $\exp[\tfrac n2\operatorname{Ein}(\Box^2/M^4)]$ times a random factor that tends to a constant at high momentum, in almost every realization. We prove that for $n\ge4$ the theory of gravity built on it has no ultraviolet divergence at any order of perturbation theory: every graph with two or more loops converges, the one-loop poles are those of a local theory and are cancelled by three operators quartic in curvature with finite coefficients, Newton's constant and the cosmological constant do not run, the zero-point energy of the graviton is $3nM^4/(64\pi^2)$ for every regulator, and the physical $S$ matrix is unitary at every loop order. The propagator keeps the graviton pole alone, and the potential of a point mass is finite at the origin. A one-loop graph in closed form confirms the cutting rule and grows faster than any exponential of the energy, so the loop expansion is an expansion in a small parameter only below an energy between $1.4M$ and $1.9M$. The free Euclidean field is a Gaussian measure with finite curvature that is not reflection positive, which states what a construction beyond perturbation theory would have to supply.

## Subjects

Primary: mathematical physics (math-ph). Secondary: high energy physics, theory (hep-th); general relativity and quantum cosmology (gr-qc).

## Keywords

nonlocal quantum gravity; ultraviolet finiteness; brane gas; entire form factors; Poisson point processes; perturbative unitarity

## License

CC BY 4.0 (the same license as the earlier preprint hexagon:2610.00342v1).

## Related work field

Earlier preprint by the same contributors: "Ghosts in Poisson Brane Gases", hexagon:2610.00342v1 (cited on the title page and in the introduction). Companion manuscript: "Brane cluster gases and ghost-free form factors for quantum gravity" (the archive of Ref. [13] of the paper). Code and figure scripts: https://github.com/creelie/brane-cluster-gases, archived at https://doi.org/10.5281/zenodo.23524276 (version 3.1.0, which holds this paper; all versions at https://doi.org/10.5281/zenodo.22866290).

## Use of AI (the statement for the "supplementary information about AI" field)

Artificial-intelligence tools (Claude Code, Anthropic) assisted with drafting and editing the text, with algebraic and numerical calculations, with the verification code and with the scripts that draw the figures. No AI system is a contributor. Every result in the paper is derived analytically in the text; no statement rests on a numerical computation or on an AI output. The contributors directed the work, re-derived and checked its results, and take full responsibility for the content. The paper's Data availability and Use of AI tools sections state the same. The verification suite (195 Python, 84 C and 114 Julia checks, 17 Lean 4 theorems) and five independent audit scripts (74 checks) that re-evaluate the formulas are public at the repository above; they are not part of this submission, as Hexagon does not accept code.

## Resubmission letter to the editor (Physical Review D)

Dear Editor,

We resubmit the manuscript "Cancellation of all ultraviolet divergences of quantum gravity by a scale-invariant gas of branes" (earlier title: "Finite quantum gravity from a scale-invariant gas of branes") by Deep Bhattacharjee and Ushashi Bhattacharya.

The paper proves one theorem. A frozen Poisson gas of branes with no preferred size multiplies the graviton kinetic operator by an entire function without zeros, exp[(n/2) Ein(Box^2/M^4)] times a random factor with a limit at high momentum, and for n >= 4 the theory of gravity built on that operator has no ultraviolet divergence at any order of perturbation theory: every graph with two or more loops converges (vertex bound and Weinberg's theorem), the one-loop poles are those of a local theory and are cancelled by three quartic operators with finite coefficients, Newton's constant and the cosmological constant do not run, the zero-point energy is finite and regulator independent, and the physical S matrix is unitary at every loop order. The paper also states what it does not prove: the loop expansion is small only below an energy of order M, and no construction beyond perturbation theory is claimed.

Changes since the previous version:

1. The title and abstract state the result proved. The abstract leads with the theorem and names each of its parts.
2. Ushashi Bhattacharya joins as second author, with a title-page footnote to our earlier preprint on the pole structure of the gas-averaged propagator (Hexagon 2610.00342v1).
3. Three new figures show the main objects as surfaces: the potential of a point mass over distance and gas strength (finite at the origin, Newtonian beyond a few units of 1/M), the bound on the superficial degree of divergence over gas strength and fine graining (negative for every graph with two or more loops when n >= 4), and the time-slice covariance of the free Euclidean graviton (its sign change, the failure of reflection positivity).
4. The bibliography has 96 entries, each resolved against its registration record. The new entries place the construction beside higher-derivative and Lee–Wick gravity, the nonlocal-gravity literature and its reviews, the nonlocal regularisation of gauge theories, the Hepp–Zimmermann and Faddeev–Popov–DeWitt foundations of the perturbative machinery, Cutkosky's rules and Sen's proof of unitarity in string field theory, the Osterwalder–Schrader and Nelson constructions, the effective-field-theory corrections to Newton's law, asymptotic safety, infrared nonlocal cosmology and the brane gases of string cosmology, and each is cited where it bears on the text.
5. The "bound" column of the one-loop bubble table is now the maximum over the range 0 < delta < 1/2 for which the inequality is stated.
6. Every result of the paper was re-derived by independent methods (exact rational arithmetic for the one-loop matrix, exhaustive enumeration for the power counting, two routes for the Mellin continuation of the vacuum energy, a Hankel test for reflection positivity, a different quadrature for the bubble). No formula had to be changed. The scripts are in the public archive cited in the Data availability section.
7. The prose was revised throughout so that every statement is either proved in the text or marked as what the paper leaves open.

The manuscript is 50 pages in the PRD two-column format, with 19 figures and 15 tables. It has not been published elsewhere and is not under consideration by another journal. The use of AI tools is declared in the paper (Data availability and Use of AI tools sections): they assisted with drafting, calculation, verification code and figure scripts; the authors directed the work, checked every result and are responsible for the content.

Yours sincerely,

Deep Bhattacharjee (corresponding author, itsdeep@live.com)
Ushashi Bhattacharya

[If the earlier decision came with referee comments, add a numbered point-by-point response here, one item per comment, each stating what was changed in the manuscript and where.]
